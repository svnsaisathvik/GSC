package com.example.backend.controller;

import com.example.backend.dto.RegisterRequest;
import com.example.backend.service.FirebaseAuthService;
import com.example.backend.service.FirestoreService;
import com.google.firebase.auth.FirebaseToken;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:8082")
public class AuthController {

    private final FirebaseAuthService firebaseAuthService;
    private final FirestoreService firestoreService;

    public AuthController(
            FirebaseAuthService firebaseAuthService,
            FirestoreService firestoreService
    ) {
        this.firebaseAuthService = firebaseAuthService;
        this.firestoreService = firestoreService;
    }

    // ✅ EXISTING SIGNUP (UNCHANGED)
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest request) throws Exception {

        String uid = firebaseAuthService.register(
                request.getEmail(),
                request.getPassword(),
                request.getName(),
                request.getRole()
        );

        return ResponseEntity.ok(Map.of("uid", uid));
    }

    // 🆕 NEW: GET CURRENT USER PROFILE
    @GetMapping("/me")
    public ResponseEntity<?> getCurrentUser(
            @RequestHeader("Authorization") String authorization
    ) throws Exception {

        // Expect: "Bearer <token>"
        String token = authorization.replace("Bearer ", "");

        FirebaseToken decodedToken = firebaseAuthService.verifyToken(token);
        String uid = decodedToken.getUid();

        Map<String, Object> userData = firestoreService.getUser(uid);

        return ResponseEntity.ok(userData);
    }
}
