package com.example.backend.dto;

public record UpdatePriceRequestDto(
        Double sellingPrice
) {}
