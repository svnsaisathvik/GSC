package com.example.backend.dto;

public record EnergyStatusDto(
        String status,
        Double sellingPrice
) {}
