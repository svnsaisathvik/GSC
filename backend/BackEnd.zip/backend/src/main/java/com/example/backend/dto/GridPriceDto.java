package com.example.backend.dto;

public record GridPriceDto(
        Double currentGridPrice
) {}
